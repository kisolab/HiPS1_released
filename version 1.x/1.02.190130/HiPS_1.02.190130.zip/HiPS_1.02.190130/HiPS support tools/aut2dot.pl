#!/usr/bin/perl

# -------------------------------------------------------------
# Convert from Aldebaran(.aut) to Graphviz(.dot) 
# Usage : perl ./aut2dot.pl foobar.aut > foobar.dot

# redering Graphviz : dot -Kdot -Tpng foobar.dot -o foobar.png
#                     dot -Kdot -Tsvg foobar.dot -o foobar.svg

# -------------------------------------------------------------

print "digraph main {\n\n";

while(<>) {
    chomp $_;
    if (/^\s*\((\d+)\s*,\s*(\S+)\s*,\s*(\d+)/){
	print "$1 -> $3 [label=$2];\n";
    } elsif (/^\s*(\d+)->(.+)/){
	$tmp1=$1; $tmp2=$2; $tmp2 =~ s/\s+//g;
	print "$tmp1 [label=\"M$tmp1$tmp2\"];\n";
    } else {
	print "// $_\n";
    }
}

print "\n}\n";

__END__
